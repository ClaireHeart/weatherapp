package com.example.weatherapp.constants;

public class AppConstant {
    public static final String BASE_URL="https://newsapi.org/v2/";

    public static final String API_KEY="c5326632ca4c40e48d84aeaecfa8a37a";
}
