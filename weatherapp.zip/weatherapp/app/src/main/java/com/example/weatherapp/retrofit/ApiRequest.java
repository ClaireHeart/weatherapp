package com.example.weatherapp.retrofit;

import static com.example.weatherapp.constants.AppConstant.API_KEY;
import com.example.weatherapp.response.ArticleResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiRequest {

    @GET("top-headlines?sources=techcrunch&apiKey="+API_KEY)
    Call<ArticleResponse> getTopHeadlines();
}
